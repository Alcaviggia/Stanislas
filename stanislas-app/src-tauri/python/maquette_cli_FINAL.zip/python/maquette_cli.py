"""
Génère une vraie image PNG de la maquette (texte posé sur un cadre aux
dimensions du format choisi), et l'ouvre pour que l'utilisateur puisse
la voir, l'enregistrer ailleurs, l'imprimer ou la joindre à un email.

Ce n'est PAS encore une image générée par IA (Flux) — juste une mise en
page propre du texte, en attendant que le générateur d'image soit relié.

Nécessite Pillow (normalement déjà installé pour Atelier image) :
    pip3 install Pillow --break-system-packages
"""
import sys
import os
import platform
import subprocess
import textwrap
from datetime import datetime

DIMENSIONS = {
    "post": (1080, 1080),
    "story": (1080, 1920),
    "banniere": (1200, 300),
    "ads": (1080, 1080),
    "print": (1240, 1748),  # A4 environ, à 150 dpi
}


def trouver_police(taille: int):
    """Cherche une police système qui gère correctement les accents français,
    sur Mac et Windows — la police par défaut de Pillow ne les affiche pas bien."""
    from PIL import ImageFont

    chemins_possibles = [
        # macOS
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        # Windows
        "C:\\Windows\\Fonts\\arial.ttf",
        "C:\\Windows\\Fonts\\segoeui.ttf",
        # Linux (au cas où)
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for chemin in chemins_possibles:
        if os.path.exists(chemin):
            try:
                return ImageFont.truetype(chemin, taille)
            except Exception:
                continue
    # Repli : la police par défaut, moins belle et sans accents corrects,
    # mais on préfère ça à un plantage si aucune police n'est trouvée
    return ImageFont.load_default(size=taille)


def trouver_police_grasse(taille: int):
    """Version en gras de la police, pour le style Impact."""
    from PIL import ImageFont
    chemins_possibles = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        "C:\\Windows\\Fonts\\arialbd.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ]
    for chemin in chemins_possibles:
        if os.path.exists(chemin):
            try:
                return ImageFont.truetype(chemin, taille)
            except Exception:
                continue
    return trouver_police(taille)


def creer_image(texte: str, format_cle: str, chemin_sortie: str, chemin_image_fond: str = None, style: str = "classique"):
    from PIL import Image, ImageDraw

    largeur, hauteur = DIMENSIONS.get(format_cle, DIMENSIONS["post"])

    if chemin_image_fond and os.path.exists(chemin_image_fond):
        # Une vraie image a été choisie : on la recadre pour remplir le cadre
        # (mode "cover" — remplit tout l'espace, quitte à rogner les bords)
        fond = Image.open(chemin_image_fond).convert("RGB")
        ratio_cible = largeur / hauteur
        ratio_fond = fond.width / fond.height
        if ratio_fond > ratio_cible:
            nouvelle_hauteur = hauteur
            nouvelle_largeur = int(hauteur * ratio_fond)
        else:
            nouvelle_largeur = largeur
            nouvelle_hauteur = int(largeur / ratio_fond)
        fond = fond.resize((nouvelle_largeur, nouvelle_hauteur))
        gauche = (nouvelle_largeur - largeur) // 2
        haut = (nouvelle_hauteur - hauteur) // 2
        image = fond.crop((gauche, haut, gauche + largeur, haut + hauteur))
    else:
        # Pas d'image choisie : on garde le motif rayé "emplacement à venir"
        image = Image.new("RGB", (largeur, hauteur), "#e8e8e0")
        dessin_fond = ImageDraw.Draw(image)
        pas = 24
        for x in range(-hauteur, largeur, pas):
            dessin_fond.line([(x, 0), (x + hauteur, hauteur)], fill="#f4f4ee", width=8)

    image = image.convert("RGBA")

    marge = int(largeur * 0.06)
    taille_police = max(20, largeur // 30)
    police = trouver_police_grasse(taille_police) if style == "impact" else trouver_police(taille_police)

    largeur_car = int((largeur - 2 * marge) / (taille_police * 0.6))
    lignes = textwrap.wrap(texte, width=max(largeur_car, 10))
    texte_multiligne = "\n".join(lignes)

    dessin_mesure = ImageDraw.Draw(image)
    bbox = dessin_mesure.multiline_textbbox((0, 0), texte_multiligne, font=police, spacing=10)
    hauteur_texte = bbox[3] - bbox[1]
    hauteur_boite = hauteur_texte + marge

    if format_cle == "print":
        y_boite = marge
    else:
        y_boite = hauteur - hauteur_boite - marge

    if style == "moderne":
        # Bandeau semi-transparent sombre, texte blanc — plus élégant sur une vraie photo
        calque = Image.new("RGBA", image.size, (0, 0, 0, 0))
        dessin_calque = ImageDraw.Draw(calque)
        dessin_calque.rectangle(
            [0, y_boite - marge / 2, largeur, y_boite + hauteur_boite + marge / 2],
            fill=(0, 0, 0, 160)
        )
        image = Image.alpha_composite(image, calque)
        dessin = ImageDraw.Draw(image)
        dessin.multiline_text(
            (marge * 1.5, y_boite + marge / 2), texte_multiligne,
            font=police, fill="white", spacing=10
        )
    elif style == "impact":
        # Texte gras avec contour noir épais, sans boîte — façon meme/affiche
        dessin = ImageDraw.Draw(image)
        x, y = marge * 1.5, y_boite + marge / 2
        for dx in (-3, 0, 3):
            for dy in (-3, 0, 3):
                dessin.multiline_text((x + dx, y + dy), texte_multiligne, font=police, fill="black", spacing=10)
        dessin.multiline_text((x, y), texte_multiligne, font=police, fill="white", spacing=10)
    else:
        # Classique : boîte blanche avec contour, texte noir
        dessin = ImageDraw.Draw(image)
        dessin.rectangle(
            [marge, y_boite, largeur - marge, y_boite + hauteur_boite],
            fill="white", outline="black", width=3
        )
        dessin.multiline_text(
            (marge * 1.5, y_boite + marge / 2), texte_multiligne,
            font=police, fill="black", spacing=10
        )

    image.convert("RGB").save(chemin_sortie)



if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--finaliser":
        # Deuxième étape : copie l'aperçu temporaire vers un fichier définitif et l'ouvre
        chemin_temp = os.path.expanduser(os.path.join("~", "Documents", "Stanislas", "Promo", ".apercu_temp.png"))
        if not os.path.exists(chemin_temp):
            print("[ERREUR] Aucun aperçu à sauvegarder. Génère d'abord un aperçu.")
            sys.exit(1)

        dossier = os.path.expanduser(os.path.join("~", "Documents", "Stanislas", "Promo"))
        horodatage = datetime.now().strftime("%Y-%m-%d_%Hh%Mm%S")
        chemin_final = os.path.join(dossier, f"promo_{horodatage}.png")

        import shutil
        shutil.copy(chemin_temp, chemin_final)

        systeme = platform.system()
        try:
            if systeme == "Darwin":
                subprocess.run(["open", chemin_final], check=True)
            elif systeme == "Windows":
                os.startfile(chemin_final)
            else:
                subprocess.run(["xdg-open", chemin_final], check=True)
        except Exception as e:
            print(f"[ERREUR ouverture] {e}")

        print(f"Enregistré : {chemin_final}")
        print("OK")
        sys.exit(0)

    if len(sys.argv) < 2:
        print("[ERREUR] Aucun texte fourni.")
        sys.exit(1)

    texte = sys.argv[1]
    format_cle = sys.argv[2] if len(sys.argv) > 2 else "post"
    chemin_image_fond = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else None
    style = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] else "classique"

    try:
        from PIL import Image
    except ImportError:
        print("Bibliothèque manquante. Lance : pip3 install Pillow --break-system-packages")
        sys.exit(1)

    dossier = os.path.expanduser(os.path.join("~", "Documents", "Stanislas", "Promo"))
    os.makedirs(dossier, exist_ok=True)
    # Écrit toujours au même endroit temporaire — pas encore le fichier final
    chemin_temp = os.path.join(dossier, ".apercu_temp.png")

    creer_image(texte, format_cle, chemin_temp, chemin_image_fond, style)

    # Encode en base64 pour que l'app puisse l'afficher directement,
    # sans avoir besoin d'accéder au système de fichiers depuis JavaScript
    import base64
    with open(chemin_temp, "rb") as f:
        contenu_base64 = base64.b64encode(f.read()).decode("ascii")

    print("---IMAGE_BASE64---")
    print(contenu_base64)
